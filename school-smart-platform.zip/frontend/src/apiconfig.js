export const API_BASE_URL = "http://localhost:8000";
export const STUDENTS_ENDPOINT = `${API_BASE_URL}/students`;